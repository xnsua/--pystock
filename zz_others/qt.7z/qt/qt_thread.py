import sys

from PyQt5.QtCore import QRunnable
from PyQt5.QtCore import QThreadPool, pyqtSignal, QObject
from PyQt5.QtWidgets import QWidget, QApplication
from qt.server_interface import *


# def buy_stock(code, price, num, method):
#     method = method.name
#     infodict = {'code': code, 'price': price, 'num': num, 'method': method,
#                 'operation': 'buy'}
#     return _send_data(infodict)
#
#
# def sell_stock(code, price, num, method):
#     method = method.name
#     infodict = {'code': code, 'price': price, 'num': num, 'method': method,
#                 'operation': 'sell'}
#     jsonstr = json.dumps(infodict)
#     return _send_data(jsonstr)
#
#
# def cancel_order(order_id):
#     infodict = {'order_id': order_id, 'operation': 'sell'}
#     jsonstr = json.dumps(infodict)
#     return _send_data(jsonstr)
class HttpSignal(QObject):
    sig_response = pyqtSignal(int)


class HttpSlot(QObject):
    def __init__(self):
        super().__init__()

    @staticmethod
    def on_response(resp):
        print('onresp')


class HttpRunnable(QRunnable):
    def __init__(self, task, callback):
        super().__init__()
        self.task = task
        self.signal = HttpSignal()
        self.signal.sig_response.connect(callback)

    def run(self):
        print('run')
        self.signal.sig_response.emit(self.task)


# def run_task_async(task, callback):
#     QThreadPool.globalInstance().start(HttpRunnable(task, callback))

class GlobalObject:
    pass


go = GlobalObject()


def main():
    go.vtask = HttpSlot()
    vrun = HttpRunnable(1, go.vtask.on_response)
    QThreadPool.globalInstance().start(vrun)
    QThreadPool.globalInstance().waitForDone()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    widget = QWidget()
    # vtask = HttpSlot()
    # vrun = HttpRunnable(1, vtask.on_response)
    # QThreadPool.globalInstance().start(vrun)
    # QThreadPool.globalInstance().waitForDone()
    main()
    widget.show()
    sys.exit(app.exec_())
